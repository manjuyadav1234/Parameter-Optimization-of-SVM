# Parameter-Optimization-of-SVM
Parameter-Optimization-of-SVM This repository presents an enhanced SVM classification model achieved through systematic hyperparameter tuning. The project includes preprocessing, model training, and optimization of key parameters (C, gamma, kernel) using techniques like Grid Search and Random Search.
